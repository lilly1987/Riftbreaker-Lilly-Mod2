return function()
    local rules = require("lua/missions/survival/v2/dom_survival_lilly_rules_default.lua")()	

    return rules;
end